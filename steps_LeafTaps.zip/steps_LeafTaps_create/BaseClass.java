package steps_LeafTaps_create;




import org.openqa.selenium.chrome.ChromeDriver;



public class BaseClass {
	
	public static ChromeDriver driver;



	}


	
	


