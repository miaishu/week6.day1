package steps_LeafTaps_duplicate;




import org.openqa.selenium.chrome.ChromeDriver;



public class BaseClass {
	
	public static ChromeDriver driver;



	}


	
	


